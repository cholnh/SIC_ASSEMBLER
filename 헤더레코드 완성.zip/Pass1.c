#include < stdio.h>
#include <string.h>
#define MAX_CHAR_SIZE 10
#define INSTRUCTION_SIZE 3

/****************************************
*              [ ����ü ]               *
*                                       *
****************************************/
typedef struct {
	char key[MAX_CHAR_SIZE];
	int value;
}sNode;

typedef struct {
	sNode node;
	struct ListNode *link;
}ListNode;

typedef struct ListHeader {
	char name[MAX_CHAR_SIZE];
	char length[MAX_CHAR_SIZE];
	ListNode *head;
	ListNode *tail;
}ListHeader;

typedef struct {
	char label[MAX_CHAR_SIZE];
	char opcode[MAX_CHAR_SIZE];
	char operand[MAX_CHAR_SIZE];
}Data;

/****************************************
*             [ Read Line ]             *
****************************************/
Data *readline(FILE *source) {
	char line[100];
	fgets(line, 100, source);
	line[strlen(line) - 1] = '\0';
	return parse(line);
}

/****************************************
*              [ Pass 1 ]               *
*                                       *
****************************************/
void pass_1(ListHeader *plist, FILE *source) {
	ListHeader *symtab = plist;
	FILE *sourceFile = source;
	Data *linedata;

	int startingAddr = 0;
	int LOCCTR = 0;
	int i = 0;
	int len = 0;
	char *startP, *endP;
	
	/* Read first line */
	linedata = readline(sourceFile);
	
	/* Initialize addr */
	if (strstr(linedata->opcode, "START")) {
		strcpy(plist->name, linedata->label);
		startingAddr = (int)strtol(linedata->operand, NULL, 16);
		LOCCTR = startingAddr;
	}

	while (!feof(sourceFile)) {
		
		/* Read line */	
		linedata = linedata = readline(sourceFile);

		if (strstr(linedata->opcode, "END")) break;
		if (strstr(linedata->label, ".")) ;
		else {
			/* ���̺��� ���� ��� */
			if (strstr(linedata->label, "-")) {
				LOCCTR += INSTRUCTION_SIZE;
				continue;
			}
			
			/* symbol �ߺ� �˻� */
			if (searchNode(symtab, linedata->label)) {
				setError("Duplicated Symbol");
				printf("\nerror code : %s\n", linedata->label);
			} 
			/* SYMTAB �߰� */
			else insert_node_last(plist, linedata->label, LOCCTR);

			/* LOCCTR ���� */
			if (getValue(linedata->opcode)) {
				LOCCTR += INSTRUCTION_SIZE;
			}
			else if (strstr(linedata->opcode, "RESW")) {
				LOCCTR += atoi(linedata->operand) * INSTRUCTION_SIZE;
			}
			else if (strstr(linedata->opcode, "RESB")) {
				LOCCTR += atoi(linedata->operand);
			}
			else if (strstr(linedata->opcode, "WORD")) {
				LOCCTR += INSTRUCTION_SIZE;
			}
			else if (strstr(linedata->opcode, "BYTE")) {
				startP = strchr(linedata->operand, '\'');
				endP = strchr(startP + 1, '\'');
				len = endP - startP - 1;
				if ((linedata->operand)[0] == 'X') 
					LOCCTR += (len + 1) / 2;
				else if ((linedata->operand)[0] == 'C') 
					LOCCTR += len;
				endP = strchr(startP, '\'');
				memcpy(linedata->operand, endP +1, len);
				(linedata->operand)[len] = '\0';
			}
			else {
				setError("Invalid Operator code");
				printf("\nerror code : %s [ %s ] %s\n", linedata->label, linedata->opcode, linedata->operand);
				return;
			}
		}
	}
	/* ���α׷� ���� */
	sprintf(plist->length, "%X", LOCCTR - startingAddr);
	fclose(sourceFile);
}
