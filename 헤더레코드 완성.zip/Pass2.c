#include <stdio.h>
#define MAX_CHAR_SIZE 10
#define INSTRUCTION_SIZE 3
#define HEADER_RECORD 'H'
#define TEXT_RECORD 'T'
#define END_RECORD 'E'

/****************************************
*              [ ����ü ]               *
*                                       *
****************************************/
typedef struct {
	char key[MAX_CHAR_SIZE];
	int value;
}sNode;

typedef struct {
	sNode node;
	struct ListNode *link;
}ListNode;

typedef struct ListHeader {
	char name[MAX_CHAR_SIZE];
	char length[MAX_CHAR_SIZE];
	ListNode *head;
	ListNode *tail;
}ListHeader;

typedef struct {
	char label[MAX_CHAR_SIZE];
	char opcode[MAX_CHAR_SIZE];
	char operand[MAX_CHAR_SIZE];
}Data;

/****************************************
*              [ Writer ]               *
****************************************/
void writer(FILE *result, char *str) {
	int i = 0;
	int len = strlen(str);

	if (len > 6) {
		setError("check : ");
		printf("%s", str);
		return;
	}
	for(i = 0 ; i < 6 - len ; i++)
		fprintf(result, "0");
	fprintf(result, "%s", str);
}

/****************************************
*              [ Pass 2 ]               *
*                                       *
****************************************/
void pass_2(ListHeader *plist, FILE *source) {
	ListHeader *symtab = plist;
	FILE *sourceFile = source;
	FILE *result;
	Data *linedata;
	int i = 0;
	char *startingAddr;

	result = fopen("result.txt", "w+");

	//printf("%s", linedata->opcode);

	/* Read first line */
	linedata = readline(source);
	if (strstr(linedata->opcode, "START")) {
		startingAddr = linedata->operand;
		linedata = readline(source);
	}
	/* Write Header Record */
	fprintf(result, "%c", HEADER_RECORD);
	for (i = 0; i < 6; i++)
		fprintf(result, "%c", symtab->name[i]);
	for (i; i < 6; i++)
		fprintf(result, " ");
	writer(result, startingAddr);
	writer(result, symtab->length);


	/////////////////////////////////////////////////////////////////////
	// �ؽ�Ʈ ���ڵ� �߰� �˰�����
	/*
	while (1) {
		if () {
		
		}
		// Write Text Record 
		fprintf(result, "\n%c", TEXT_RECORD);
	}
	*/
	

	/////////////////////////////////////////////////////////////////////

	fclose(sourceFile);
	fclose(result);
}
